module Liftoff
  VERSION = '1.1.2'
end
